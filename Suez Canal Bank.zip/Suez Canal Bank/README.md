# dayra001
- test automation task
-please make sure to install cypress and npm package
-using visualcode and javascript
